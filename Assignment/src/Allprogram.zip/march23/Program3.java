package march23;

public class Program3 {

	public static void main(String[] args) {
		
		int a=30;
		int b=40;
		
		System.out.println(a+" "+b);
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println(a+" "+b);
	}
}
