package march23;

public class Program19 {

	public static void main(String[] args) {
		
		int n=100;
		int i=1;
		while(i<=n)
		{
			if(i%2==1)
			{
				System.out.println(i+" ");
			}
			i++;
		}
	}
}
