package March15;

public class elseIfLaddar {

	public static void main(String[] args) {      
	      
	    int boy=25;    
	    int girl=48;      
	      
	    if(boy>=21)
	    {      
	        if(girl>=18)
	        {    
	            System.out.println("You are eligible to marry");    
	        }
	        else
	        {  
	            System.out.println("You are not eligible to marry");    
	        }  
	    }
	    else
	    {  
	      System.out.println("Age must be greater than 18");  
	    }  
	} 
	
}  

