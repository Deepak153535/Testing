package March15;

public class GoodMorning1 {

	public static void main(String[] args) {
		
		int a=8,b=10,c=11;
		
		if(a>=8)
		{
			System.out.println("Good Morning");
		}
		else if(b>=10)
		{
			System.out.println("Good Morning");
		}
		else if(c>=11)
		{
			System.out.println("Goog Morning");
		}
		else
		{
			System.out.println("Good");
		}
	}
}
