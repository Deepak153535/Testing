package March15;

public class Marry {

	public static void main(String[] args) {
		
		int i=20;
		
		if(i>=21)
		{
			System.out.println("You are Eligible to marry");
		}
		else
		{
			System.out.println("You are not eligible to marry");
		}
	}
}
