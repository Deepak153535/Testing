package March15;

public class GoodMorning {

	public static void main(String[] args) {
		
		int time=9;
		
		if(time==8)
		{
			System.out.println("Good Morning");
		}
		else
		{
			System.out.println("Good ");
		}
	}
}
