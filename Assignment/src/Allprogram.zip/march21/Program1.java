package march21;

public class Program1 {

	public static void main(String[] args) {

		if (true) {
			System.out.println("hello");
			System.out.println("gm");
		} else {
			System.out.println("hi");
		}
	}
}
