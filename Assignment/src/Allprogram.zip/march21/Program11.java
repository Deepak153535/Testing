package march21;

public class Program11 {

	public static void main(String[] args) {
		int i = 20;
		while (i >= 10) {
			if (i % 2 == 1) {
				System.out.println(i);
			}
			i--;
		}
	}
}
