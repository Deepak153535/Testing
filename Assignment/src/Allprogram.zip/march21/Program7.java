package march21;

public class Program7 {

	public static void main(String[] args) {
		int i = 20;
		while (i >= 10) {
			System.out.println(i);
			i--;
		}
	}
}
