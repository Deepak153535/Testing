package march21;

public class Program10 {

	public static void main(String[] args) {
		int i = 19;
		while (i >= 9) {
			if (i % 2 == 0) {
				System.out.println(i);
			}
			i--;
		}
	}
}
