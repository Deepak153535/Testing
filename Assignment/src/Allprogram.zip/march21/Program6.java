package march21;

public class Program6 {

	public static void main(String[] args) {

		int sum = 0;
		int i = 1;
		while (i <= 10) {
			System.out.println(i);
			// sum = sum + i;
			i++;
		}
		// System.out.println(sum);
	}
}
