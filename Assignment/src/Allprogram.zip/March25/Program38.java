package March25;

public class Program38 {

	public static void main(String[] args) {
		
		int i=1;
		while(i<=100)
		{
			if(i%9==0)
			{
				System.out.println("Divisible by 9 : "+i);
			}
			i++;
		}
	}
}
