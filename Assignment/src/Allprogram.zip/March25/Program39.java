package March25;

public class Program39 {

	public static void main(String[] args) {
		
		int i=1;
		while(i<=20)
		{
			if(i%2==0 || i%4==0)
			{
				System.out.println("Divisible by 2 or 4 : "+i);
			}
			i++;
		}
	}
}
