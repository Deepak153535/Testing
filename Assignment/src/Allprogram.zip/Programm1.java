
public class Programm1 {
public static void main(String[] args) {
	int a=13456;
	int temp=0;
	int sum=0;
	int n=5;
	while(n>=0){
		a=a%10;
		if(a%2==0){
			System.out.println(a);			
			
		}
		
		n--;
		
}
}
}